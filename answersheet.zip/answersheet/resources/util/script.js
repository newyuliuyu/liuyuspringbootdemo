$.fn.extend({
    radios: function (options) {
        var self = this;
        return this.each(function () {
            var _this = $(this);
            $('label', this).each(function () {
                $(this).addClass('Radio');
                if ($(this).children().is(":checked")) {
                    $(this).addClass('RadioChecked');
                    _this.find('label').not($(this)).removeClass("RadioChecked");
                }
            }).click(function (event) {
                _this.find('label').not($(this)).removeClass("RadioChecked");
                if (!$(this).children().is(':checked')) {
                    $(this).addClass("RadioChecked");
                    $(this).children()[0].checked = true;
                }
                event.stopPropagation();
            }).children().hide();
        });
    },
    checkBox: function (options) {
        var defaults = {
            itemTag: 'label',
            checkAllTag: false,
            template: '<label class="chkAll"><input type="checkbox" value="999" /><span>全选</span></label>'
        };
        options = $.extend({}, defaults, options);
        this.each(function () {
            var _this = $(this);
            //var oChkAll = chkAll? _this.find(chkAll):_this.find('label.chkAll');
            var chkCell = options.itemTag;
            if (options.checkAllTag) {
                var temp = $(options.template);
                _this.append(temp);
            }
            var checkAll = options.checkAllTag ? _this.find('.chkAll') : null;
            $(chkCell, this).each(function () {
                $(this).addClass('checkbox');
                if ($(this).children().is(':disabled') == false) {
                    if ($(this).children().is(':checked')) $(this).addClass("checked");
                } else {
                    $(this).addClass('disabled');
                }

            }).click(function (event) {
                if (!$(this).children().is(':checked')&&!$(this).children().is(':disabled')) {
                    $(this).addClass("checked").children()[0].checked = true;
                    if (options.checkAllTag) {
                        var aLabel = _this.find('.checkbox').not('.chkAll');
                        aLabel.each(function (index) {
                            if (!$(this).children().is(':checked')) return false;
                            if (index >= aLabel.length - 1) {
                                checkAll.addClass('checked').children()[0].checked = true;
                            }
                        });
                    }
                } else {
                    $(this).removeClass('checked').children()[0].checked = false;
                    if (options.checkAllTag) {
                        if (checkAll.hasClass('checked')) checkAll.removeClass('checked').children()[0].checked = false;
                    }

                }
                event.stopPropagation();
                return false;
            });
            if (options.checkAllTag) {
                checkAll.click(function () { //增加全选
                    var Flag = $(this).children().is(':checked');
                    if (chkCell.indexOf('label') == 0) chkCell = chkCell + '.checkbox';
                    _this.find(chkCell).each(function () {
                        if (Flag) {
                            $(this).addClass("checked").children()[0].checked = true;
                        } else {
                            $(this).removeClass('checked').children()[0].checked = false;
                        }
                    });
                });
            }

        });
    },
    Selector: function (options) {
        var defaults={
            callback:function () {
            }
        };
        options=$.extend({},defaults,options);
        $(this).each(function () {
            $(".selecterValue").hover(
                function () {
                    $(this).addClass("bluebor")
                },
                function () {
                    $(this).removeClass("bluebor")
                }
            );
            var Myobj = $(this);
            var oInp = Myobj.find('input.selRes');
            Myobj.find(".selecterDrop a").each(function () {
                if ($(this).hasClass('active')) {
                    Myobj.find(".selecterValue p").html($(this).html());
                    if (oInp[0]) oInp.val($(this).attr('value'));
                    return false;
                }
            });
            Myobj.unbind().on('click', function (ev) {
                var Ocur = $(this).find(".selecterValue");
                var Odrop = $(this).find(".selecterDrop");
                var Owidth = $(this).width();
                Odrop.toggle(0, function () {
                    $(this).css({
                        'z-index': 9999,
                        "width": parseInt(Odrop.css('width')) > Owidth ? Odrop.css('width') : Owidth
                    });
                });


                $(".selecterBox").not($(this)).find(".selecterDrop").hide();
                ev.stopPropagation();
                $(document).click(function () {
                    $(".selecterDrop").hide();
                });
                Odrop.find("a").unbind().on('click', function () {
                    Ocur.find("p").html($(this).html());
                    Odrop.hide();
                    $(this).addClass('active').siblings().removeClass('active');
                    if (oInp[0]) oInp.val($(this).attr('value'));
                    options.callback();
                    return false;
                });
            });
        });
    }
});

$('body').on("mouseover mouseout",'.uerbox',function(event){
 if(event.type == "mouseover"){
  //鼠标悬浮
	$(this).find('.drop_wrap').stop(false,true).fadeIn();
    return false;
 }else if(event.type == "mouseout"){
  //鼠标离开
	$(this).find('.drop_wrap').stop(false,true).fadeOut();
    return false;
 }
})
/*
$('.uerbox').hover(function () {
    $(this).find('.drop_wrap').stop(false,true).fadeIn();
    return false;
},function () {
    $(this).find('.drop_wrap').stop(false,true).fadeOut();
    return false;
});
*/
