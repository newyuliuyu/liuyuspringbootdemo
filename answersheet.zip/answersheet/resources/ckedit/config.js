/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {

	//项目名称：
    CKEDITOR.config.wiriscontextpath = 'abc';
    //增加对空的 span 标签的支持
    config.protectedSource.push(/<span[^>]><\/span>/g);
    CKEDITOR.dtd.$removeEmpty['span'] = false;

    //工具栏是否可以被收缩
    config.toolbarCanCollapse = false;
    config.image_previewText=' ';
    config.forcePasteAsPlainText = false;
    config.allowedContent = true;
    config.enterMode = CKEDITOR.ENTER_BR;//enter实现换行
    config.pasteFromWordRemoveStyles = true;
    config.pasteFromWordRemoveFontStyles = true;

	
	config.extraPlugins = 'easyUnderline,easyUnderlineSwitch';

	config.toolbarGroups = [
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup'] },
		{ name: 'links', groups: [ 'links' ] },
		{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
		{ name: 'insert', groups: [ 'insert' ] },
		{ name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
		{ name: 'forms', groups: [ 'forms' ] },
		{ name: 'tools', groups: [ 'tools' ] },
		{ name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
		{ name: 'others', groups: [ 'others' ] },
		'/',
		{ name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi', 'paragraph' ] },
		{ name: 'styles', groups: [ 'styles' ] },
		{ name: 'colors', groups: [ 'colors' ] },
		{ name: 'about', groups: [ 'about' ] }
	];

	config.removeButtons = 'Subscript,Superscript,Maximize,Source,HorizontalRule,Link,Unlink,Anchor,Scayt,Cut,Copy,Paste,PasteText,PasteFromWord,Strike,RemoveFormat,NumberedList,BulletedList,Indent,Outdent,Blockquote,Format,About,Styles';


	// Set the most common block elements.
	config.format_tags = 'p;h1;h2;h3;pre';

	// Simplify the dialog windows.
	config.removeDialogTabs = 'image:advanced;link:advanced';
};
