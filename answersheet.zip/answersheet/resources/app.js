window['getScrollerTop'] = function() {
	return document.body.scrollTop || document.documentElement.scrollTop;
};

window['getClientHeight'] = function() {
	return document.documentElement.clientHeight;
};

window['getClientWidth'] = function() {
	return document.documentElement.clientWidth;
};

window['getTopOf'] = function(elment) {
	var top = 0;
	while (elment) {
		top += elment.offsetTop;
		elment = elment.offsetParent;
	}
	return top;
};

window['getLeftOf'] = function(elment) {
	var left = 0;
	while (elment) {
		left += elment.offsetLeft;

		elment = elment.offsetParent;
	}
	return left;
};

//兼容IE11（以测试）
if (!String.prototype.startsWith) {
	String.prototype.startsWith = function(str) {
		var reg = new RegExp("^" + str);
		return reg.test(this);
	}
}

Array.prototype.remove = function(obj) {
	var index = -1;
	for (var i = 0; i < this.length; i++) {
		if (this[i] == obj) {
			index = i;
			break;
		}
	}
	if (index != -1) {
		this.splice(index, 1);
	}
}

// 数组元素去重
Array.prototype.unique = function() {
	var n = { } , r = []; // n为hash表，r为临时数组
	for (var i = 0; i < this.length; i++) // 遍历当前数组
	{
		if (!n[this[i]]) // 如果hash表中没有当前项
		{
			n[this[i]] = true; // 存入hash表
			r.push(this[i]); // 把当前数组的当前项push到临时数组里面
		}
	}
	return r;
}
// 时间格式花
Date.prototype.format = function(fmt) {
	if (fmt === undefined) {
		fmt = "yyyy-MM-dd";
	}

	var o = {
		"M+"	: this.getMonth() + 1, // 月份
		"d+"	: this.getDate(), // 日
		"h+"	: this.getHours(), // 小时
		"m+"	: this.getMinutes(), // 分
		"s+"	: this.getSeconds(), // 秒
		"q+"	: Math.floor((this.getMonth() + 3) / 3), // 季度
		"S"		: this.getMilliseconds()
		// 毫秒
	};
	if (/(y+)/.test(fmt)) {
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	}
	for (var k in o) {
		if (new RegExp("(" + k + ")").test(fmt)) {
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		}
	}
	return fmt;
}
// 时间格式花
Date.prototype.addDay = function(day) {
	var a = this.valueOf();
	a = a + day * 24 * 60 * 60 * 1000;
	a = new Date(a);
	return a;
}

/**
 * @description 利用占位符格式化字符串 例如："你好，{0}, {1}".format('aa', 'Nice to meet you!') = "你好，aa Nice to meet you!";
 */
String.prototype.format = function() {
	var s = this , i = arguments.length;

	while (i--) {
		s = s.replace(new RegExp(
		        '\\{' + i + '\\}', 'gm'), arguments[i]);
	}
	return s;
};

/**
 * 四舍五入时，无小数时，不要0。 例如：Number(156).toFixed(1); 输出156.0 ，Number(156).toFixed2(1);输出156
 * 
 * @param n
 * @returns {number}
 */
Number.prototype.toFixed2 = function(n) {
	var p = Math.pow(10, n);
	return this.toFixed(n) * p / p;
}

function getUrlFileName() {
	var pathname = window.location.pathname;
	if (pathname == '' || pathname == '/')
		return 'index';
	var pathArr = pathname.split("/");
	var fileName = (pathArr[pathArr.length - 1] == '') ? 'index' : pathArr[pathArr.length - 1].split(".")[0];
	return fileName;
}

function getBrowser() {
	var browser = { };
	var ua = navigator.userAgent.toLowerCase();
	var s;
	// 浏览器
	(s = ua.match(/msie ([\d.]+)/)) ? browser.ie = s[1] : (s = ua.match(/firefox\/([\d.]+)/)) ? browser.firefox = s[1] : (s = ua.match(/chrome\/([\d.]+)/)) ? browser.chrome = s[1] : (s = ua
	    .match(/opera.([\d.]+)/)) ? browser.opera = s[1] : (s = ua.match(/version\/([\d.]+).*safari/)) ? browser.safari = s[1] : 0;
	// 移动设备
	(s = ua.match(/ipad/i)) ? browser.ipad = true : (s = ua.match(/iphone os/i)) ? browser.iphone = true : (s = ua.match(/midp/i)) ? browser.midp = strue : (s = ua.match(/android/i))
	    ? browser.android = true
	    : (s = ua.match(/windows ce/i)) ? browser.windowsCE = true : (s = ua.match(/windows mobile/i)) ? browser.windowsMobile = true : 0;
	browser.isMobile = function() {
		return browser.ipad || browser.iphone || browser.midp || browser.android || browser.windowCE || browser.windowsMobile;
	};
	return browser;
}

if (!window.app) {
	var includeRootPath = document.body.getAttribute('rootPath');
	if (includeRootPath != null) {
		window.app = {
			rootPath	: includeRootPath
		};
	}
	// 如果没有设置 window.app
	var includeEntry = document.body.getAttribute('entry');
	if (includeEntry != null) {
		// 如果body内有设置entry属性
		window.app.entry = includeEntry;
	} else {
		// 如果两个都没有设置则自动加载与网址后缀名相同的js
		window.app.entry = getUrlFileName();
	}
	if (!window.app.jsMehtod) {
		window.app.jsMehtod = 'render';
	}
}

var config = {
	urlArgs	    : '',
	contextPath	: window.app.rootPath,
	baseUrl	    : window.app.rootPath + 'resources/',
	config	    : { },
	optimize	  : 'none',
	paths	      : {
		// 'jquery' : 'lib/jquery1.12.4',
		'jquery'		       : 'lib/jquery-2.1.1',
		'echarts'		       : 'lib/echarts/echarts3',
		// 'bootstrap' : 'lib/bootstrap.min3.3.7',
		'bootstrap'		     : 'lib/bootstrap.min',
		'datetimepicker'		: 'lib/bootstrap-datetimepicker',
		'bootstrapselect'		: 'lib/bootstrap-select',
		'webuploader'		   : 'lib/webuploader',
		'pager'		         : 'lib/jquery.pager',
		'iframeTransport'		: 'lib/fileupload9.17.0/jquery.iframe-transport',
		'uploadfile'		   : 'lib/fileupload9.17.0/jquery.fileupload',
		'jquery.ui.widget'	: 'lib/jqueryui/jquery.ui.widget',
		'script'		       : 'util/script',
		'css'		           : 'lib/css0.1.10',
		'text'		         : 'lib/text2.0.15',
		'dot'		           : 'lib/doT2.0.0',
		'dialog'		       : 'commons/dialog',
		'logger'		       : 'commons/logger'
	},
	map	        : {
		'*'	: {
			'css'		: 'css',
			'text'	: 'text'
		}
	},
	shim	      : {
		// 'jquery.colorize': {
		// deps: ['jquery'],
		// exports: 'jQuery.fn.colorize'
		// },
		'bootstrap'		    : {
			deps	: ['jquery', 'css!styles/bootstrap/bootstrap']
		},
		'datetimepicker'	: {
			deps	: ['bootstrap', 'css!styles/bootstrap/bootstrap-datetimepicker']
		},
		'bootstrapselect'	: {
			deps	: ['bootstrap', 'css!styles/bootstrap/bootstrap-select']
		},
		'script'		      : {
			deps	: ['jquery']
		},
		'uploadfile'		  : {
			deps	: ['jquery', 'jquery.ui.widget', 'iframeTransport']
		},
		'dialog'		      : {
			deps	: ['jquery', 'css!styles/dialog']
		},
		'pager'		        : {
			deps	: ['jquery']
		}
	}
};

requirejs.config(config);
// 'bootstrap', 'dot', 'bootstrapselect', 'datetimepicker', 'css!styles/bootstrap/bootstrap.min', 'css!styles/public', 'css!styles/style',
// 'css!styles/index',
// 'css!styles/report'
var globalModel = ['jquery'];
require(globalModel, function($) {

	    var p = ['app/' + window.app.entry];
	    if (!window.JSON) {// 如果浏览器不支持JSON，使用JSON2
		    p[1] = 'util/json3';
	    }

	    var $include = $('include');
	    var size = $include.size();
	    var b = p.length;
	    for (var i = 0; i < size; i++) {
		    p[b + i] = 'text!' + $($include[i]).attr('src');
	    }

	    require(p, function() {
		    for (var i = 0; i < size; i++) {
			    $($include[i]).append(arguments[b + i]);
		    }
		    var module = arguments[0];
		    if (module) {
			    if (window.app.jsMethod && window.app.jsMethod != '') {
				    module[window.app.jsMethod]();
			    } else {
				    module.render();
			    }
		    }

	      });
    });
