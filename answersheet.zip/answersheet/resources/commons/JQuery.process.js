(function() {
	"use strict";
	var dps = ['jquery', 'commons/ajax'];
	define(dps, function($, $ajax) {

		var Process = function(_opts) {
			var opts = {
				url				       : '',
				target				   : '',
				debug				     : true,
				completed				 : 0,
				finishedCallBack	: undefined,
				callBack				 : undefined
			};
			$.extend(opts, _opts);
			if (opts.target.has('.progress').size()) {
				return;
			}

			function createUI() {
				var template = '<div class="progress progress2" style="width:100%;">\
	    										<div class="progress-bar progress-bar2">0%</div>	\
										    	</div>\
										    	<div class="mytext">\
										    	</div>';
				opts.target.append(template);
			}

			function getUrl() {
				if (opts.debug) {
					return opts.url + "?complete=" + opts.completed;
				} else {
					return opts.url;
				}
			}
			function startProcess() {
				var url = getUrl();
				$ajax.getJson(url).then(function(dataset) {
					    var process = dataset.process;
					    processDataset(process);
				    });
			}

			function processDataset(progress) {
				console.log(progress)
				var percent = progress.percent + "%";
				var finished = progress.finished;
				var text = progress.text;
				var $target = opts.target;
				opts.completed = progress.completed;

				$target.find('.progress-bar').css('width', percent).text(percent);
				$target.find('.mytext').text(text);
				if ($.isFunction(opts.callBack)) {
					opts.callBack(progress);
				}
				if (finished) {
					if ($.isFunction(opts.finishedCallBack)) {
						opts.finishedCallBack();
					}
				} else {
					setTimeout(function() {
						    startProcess();
					    }, 3000);
				}
			}

			createUI();
			startProcess();
		}

		$.fn.extend( {
			    'process'	: function(_opts) {
				    var opts = {
					    url			: '',
					    target	: ''
				    };
				    if ($.isPlainObject(_opts)) {
					    $.extend(opts, _opts);
				    } else {
					    opts.url = _opts;
					    opts.target = $(this);
				    }
				    new Process(opts);
			    }
		    });
	});
})();