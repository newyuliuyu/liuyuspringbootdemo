(function() {
	window.FourRatioHelper = function(scoreInfos, fullScore, yxl, lhl, jgl, dfl) {
		// scoreInfos 是一个数组，格式为{score:0,num:1}
		var yxlScore = fullScore * yxl;
		var lhlScore = fullScore * lhl;
		var jglScore = fullScore * jgl;
		var dflScore = fullScore * dfl;

		var yxlNum = 0;
		var lhlNum = 0;
		var jglNum = 0;
		var dflNum = 0;
		var totalNum = 0;

		var size = scoreInfos.length;
		for (var i = 0; i < size; i++) {
			var scoreInfo = scoreInfos[i];
			totalNum += scoreInfo.num;
			if (scoreInfo.score >= yxlScore) {
				yxlNum += scoreInfo.num;
			} else if (scoreInfo.score >= lhlScore) {
				lhlNum += scoreInfo.num;
			} else if (scoreInfo.score >= jglScore) {
				jglNum += scoreInfo.num;
			} else if (scoreInfo.score < dflScore) {
				dflNum += scoreInfo.num;
			}
		}
		return {
			yxlNum		: yxlNum,
			lhlNum		: lhlNum,
			jglNum		: jglNum,
			dflNum		: dflNum,
			totalNum	: totalNum
		};
	}
	window.SegmentHelper = function(scoreInfos, fullScore, segment) {
		// scoreInfos 是一个数组，格式为{score:0,num:1}
		var segments;
		var totalNum = 0;
		function init() {
			segments = new Array();
			for (var i = 0; i < fullScore; i += segment) {
				var s = { }
				s.begin = i;
				s.end = i + segment;
				s.num = 0;
				s.addUpNum = 0;
				segments.push(s);
			}
		}

		function calcualteSegment() {
			var size = scoreInfos.length;
			for (var i = 0; i < size; i++) {
				var scoreInfo = scoreInfos[i];
				var optionValue = scoreInfo.score / segment;
				var option = optionValue.toFixed2(0);
				var tmp = null;
				if (option >= size) {
					tmp = segments[size - 1];
				} else {
					tmp = segments[option];
				}
				tmp.num = tmp.num + scoreInfo.num;
				totalNum+=scoreInfo.num;
			}
		}

		function getResult() {
			segments.sort(function(o1, o2) {
				    return o1.begin - o2.begin;
			    });
			var size = segments.length;
			var up = null;
			for (var i = 0; i < size; i++) {
				var segment = segments[i];
				if (up == null) {
					segment.addUpNum = segment.num;
				} else {
					segment.addUpNum = up.addUpNum + segment.num;
				}
				segment.totalNum = totalNum;
				up = segment;
				
			}
			return segments;
		}

		init();
		calcualteSegment();
		return getResult();
	}

	window.ezRequest = {
		// 获取URL参数
		QueryString		: function(item) {
			var svalue = location.search.match(new RegExp(
			    "[\?\&]" + item + "=([^\&]*)(\&?)", "i"));
			return svalue ? svalue[1] : svalue;
		},

		/**
		 * @param url
		 *          目标url
		 * @param arg
		 *          需要替换的参数名称
		 * @param arg_val
		 *          替换后的参数的值
		 * @return url 参数替换后的url
		 */
		changeURLArg	: function(url, arg, arg_val) {
			var pattern = arg + '=([^&]*)';
			var replaceText = arg + '=' + arg_val;
			if (url.match(pattern)) {// 如果没有此参数，添加
				var tmp = '/(' + arg + '=)([^&]*)/gi';
				tmp = url.replace(eval(tmp), replaceText);
				return tmp;
			} else {// 如果有此参数，修改
				if (url.match('[\?]')) {
					return url + '&' + replaceText;
				} else {
					return url + '?' + replaceText;
				}
			}
			return url + '\n' + arg + '\n' + arg_val;
		},

		/**
		 * @param url
		 *          目标url
		 * @param params
		 *          参数对象，可是是多个 格式如：[{arg:01,arg_val:11},{arg:00,arg_val:12}]
		 */
		changeURLArgs	: function(url, params) {
			var lastPattern = "";
			for (var item in params) {
				var pattern = params[item].arg + '=([^&]*)';
				var replaceText = params[item].arg + '=' + params[item].arg_val;
				if (url.match(pattern)) {// 如果没有此参数，添加
					var tmp = '/(' + params[item].arg + '=)([^&]*)/gi';
					tmp = url.replace(eval(tmp), replaceText);
					return tmp;
				} else {// 如果有此参数，修改
					if (url.match('[\?]')) {
						return url + '&' + replaceText;
					} else {
						return url + '?' + replaceText;
					}
				}
			}
		},

		/**
		 * 去除指定的url参数
		 * 
		 * @param url
		 * @param param
		 * @returns {*}
		 */
		cutURLParam		: function(url, param) {
			var url1 = url;
			if (url.indexOf(param) > 0) {
				if (url.indexOf("&", url.indexOf(param) + param.length) > 0) {
					url1 = url.substring(0, url.indexOf(param)) + url.substring(url.indexOf("&", url.indexOf(param) + param.length) + 1);
				} else {
					url1 = url.substring(0, url.indexOf(param) - 1);
				}
				return url1;
			} else {
				return url1;
			}
		}
	};
})();
