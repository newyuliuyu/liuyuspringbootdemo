(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {
		    var FilpContainer = function(_opts) {
			    var opts = { }
			    var mouseWheelScrollStart = 0;

			    function init() {
				    $.extend(opts, _opts);
			    }

			    this.flipContainer = function() {
				    var height = this.flipContainerResize();
				    // 只有一页的时候不显示
				    if ($(opts.selected + '>div').size() < 2) {
					    return;
				    }

				    var $ui = $("<ul/>", {
					        'class'	: 'circular'
				        });
				    $(opts.selected + '>div').each(function(idx) {

					        var active = '';
					        if (idx == 0) {
						        active = 'active';
					        }
					        $ui.append('<li class="' + active + '" top="' + (idx * height) + '" idx="' + idx + '"><span> <span></span></span></li>');
				        });
				    $(opts.selected).append($ui);
				    $ui.on('click', 'li', function() {
					        $ui.find('li').removeClass('active');
					        $(this).addClass('active');
					        // var top =$("#flipContainer>div:eq("+$(this).attr("idx")+")").height();
					        var top = $(this).attr("top");
					        $(opts.selected).animate( {
						            scrollTop	: top
					            }, 500);
				        });

				    $('body').on('mousewheel', function(e) {
					        if (Date.now() > mouseWheelScrollStart + 500) {
						        mouseWheelScrollStart = Date.now();
						        if (isScrollingUp(e)) {
							        $(opts.selected + ' li.active').prev().click();
						        } else {
							        $(opts.selected + ' li.active').next().click();
						        }
					        }
				        });
			    }

			    function isScrollingUp(ev) {
				    var e = window.event || ev;
				    var wheely = (e.wheelDelta || -e.detail || e.originalEvent.detail);
				    var delta = Math.max(-1, Math.min(1, wheely));
				    if (e.originalEvent && e.originalEvent.detail) {
					    if (delta > 0) {
						    return false;
					    }
				    } else if (delta < 0) {
					    return false;
				    }
				    return true;
			    }

			    this.flipContainerResize = function() {
				    var marginTop = parseInt($('.wrapper').css("margin-top").replace("px", ""));
				    var height = $('.footer').height();
				    var allHeight = $(window).height();
				    var realHeight = allHeight - height - marginTop - 150;

				    $(opts.selected).height(realHeight);
				    $('ul.circular>li').each(function(idx) {
					        $(this).attr("top", idx * realHeight);
				        });
				    return realHeight;
			    }

			    init();
		    }
		    return {
			    getInstance	: function(_opt) {
				    var opt = {
					    selected	: '#flipContainer'
				    }
				    if ($.isPlainObject(_opt)) {
					    $.extend(opt, _opt);
				    } else if ((typeof _opt == 'string') && _opt.constructor == String) {
					    opt.selected = _opt;
				    }

				    var fc = $(opt.selected).data('fc');
				    if (!fc) {
					    fc = new FilpContainer(opt);
					    $(opt.selected).data('fc', fc);
				    }
				    return fc;
			    }
		    }
	    });
})();