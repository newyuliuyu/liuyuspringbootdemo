(function() {
	"use strict";
		
	var models = ['jquery','commons/dialog','dot','commons/observer','css!styles/dialog'];
	
	define(models, function($,dialog,dot) {
		$.subscribe('ui.itemGroup.info',function(){
			$('.itemContent').empty();
			var itemGroups = window.answersheet.data.page.itemGroups;
			var nos = new Array();

			$.each(itemGroups,function(idx,itemGroup){
				var items = itemGroup.items;
				var itemText = new Array();
				var begin = 0;
				var pre = -1;
				var size  = items.length;
				$.each(items,function(idx,item){
					var no  = item.no;
					nos.push(no);
					if(idx === 0){
						begin = no;
					}else if(no - pre !== 1){
						itemText.push(begin+'-'+pre);
						begin = no;
					}else if(size === (idx+1)){
						itemText.push(begin+'-'+no);
					}
					pre = no;
				});
				var html = '<div class="itemList">\
							<span class="sl">'+itemGroup.title+'</span>\
							<span title="abc" class="sr">'+itemText.join(",")+'</span>\
						</div>';
				$('.itemContent').append(html);
			});
			window.answersheet.nos =nos;
		});



		$.subscribe('ui.showAddChoiceQuestionsUI',function(e,ownid){
			var dialogConfig = {};
			dialogConfig.header={text:'+增加选择题'};
			dialogConfig.footer={buttons:[]};
			dialogConfig.footer.buttons[0]={
				type			: 'button',
				text			: "确定",
				clazz			: 'btn-primary',
				callback	: function(){
					addChoiceQuestions($(this),ownid);
				}
			};
			var ui  = $('#addChoiceQuestionT').clone();
			var no = window.answersheet.getMaxNo();
			ui.find('#itemNoBegin').val(no);
			dialogConfig.body=ui;
			dialog.nonmodal(dialogConfig)
		});

		function addChoiceQuestions($this,ownid){
			var $dialog = $this.data('dialog');

			var beginNo = $dialog.find('#itemNoBegin').val().trim();
			if(!isInt(beginNo)){
				$dialog.find('#itemNoBegin').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('开始题号必须为正整型;');
				return false;
			}
			beginNo = parseInt(beginNo);
			var endNo = $dialog.find('#itemNoEnd').val().trim();
			if(!isInt(endNo)){
				$dialog.find('#itemNoEnd').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('结束题号必须为正整型;');
				return false;
			}
			endNo = parseInt(endNo);
			var optionCount = $dialog.find('#optionCount').val().trim();
			if(!isInt(optionCount)){
				$dialog.find('#optionCount').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('选项个数必须为正整型;');
				return false;
			}
			optionCount = parseInt(optionCount);

			if(endNo-beginNo<0){
				$dialog.find('#msg').text('结束题号必须大于或者等于开始题号;');
				return false;
			}
			var itemgroup = {
				name:'choiceQuestions',
				title:'选择题',
				items:[]
			};
			if(ownid){
				itemgroup.id = ownid;
			}
			for(var i=beginNo;i<=endNo;i++){
				itemgroup.items.push({no:i,optionCount:optionCount});
			}
			answersheet.addItemGroup(itemgroup);

			$.publish('answersheet.reDraw');
			$.publish('ui.itemGroup.info');
			$this.trigger('close');
			
		}

		function isInt(value){
			var t  = /^[0-9]*$/;
			return t.test(value);
		}


		$.subscribe('ui.showAddFillBlackQuestionsUI',function(e,ownid){
			var dialogConfig = {};
			dialogConfig.header={text:'+增加填空题'};
			dialogConfig.footer={buttons:[]};
			dialogConfig.footer.buttons[0]={
				type			: 'button',
				text			: "确定",
				clazz			: 'btn-primary',
				callback	: function(){
					addFillBlankQuestions($(this),ownid);
				}
			};
			var ui  = $('#addFillBlankTitleT').clone();
			var no = window.answersheet.getMaxNo();
			ui.find('#itemNoBegin').val(no);
			dialogConfig.body=ui;
			dialog.nonmodal(dialogConfig)
		});

		function addFillBlankQuestions($this,ownid){
			var $dialog = $this.data('dialog');

			var beginNo = $dialog.find('#itemNoBegin').val().trim();
			if(!isInt(beginNo)){
				$dialog.find('#itemNoBegin').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('开始题号必须为正整型;');
				return false;
			}
			beginNo = parseInt(beginNo);
			var endNo = $dialog.find('#itemNoEnd').val().trim();
			if(!isInt(endNo)){
				$dialog.find('#itemNoEnd').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('结束题号必须为正整型;');
				return false;
			}
			endNo = parseInt(endNo);
			var optionCount = $dialog.find('#optionCount').val().trim();
			if(!isInt(optionCount)){
				$dialog.find('#optionCount').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('空格数必须为正整型;');
				return false;
			}
			optionCount = parseInt(optionCount);

			if(endNo-beginNo<0){
				$dialog.find('#msg').text('结束题号必须大于或者等于开始题号;');
				return false;
			}

			var itemgroup = {
				name:'fillBlankQuestion',
				title:'填空题',
				content:'',
				colNum:optionCount,
				items:[]
			};
			if(ownid){
				itemgroup.id = ownid;
			}
			var noNum = endNo - beginNo+1;
			var row  = Math.floor(noNum/optionCount);
			if(noNum%optionCount !== 0){
				row+=1;
			}
		
			itemgroup.height = row*10;
			for(var i=beginNo;i<=endNo;i++){
				itemgroup.items.push({no:i});
			}

			answersheet.addItemGroup(itemgroup);

			$.publish('answersheet.reDraw');
			$.publish('ui.itemGroup.info');
			$this.trigger('close');
		}

		$.subscribe('ui.showAddAnswerQuestionUI',function(e,ownid){
			var dialogConfig = {};
			dialogConfig.header={text:'+增加解答题'};
			dialogConfig.footer={buttons:[]};
			dialogConfig.footer.buttons[0]={
				type			: 'button',
				text			: "确定",
				clazz			: 'btn-primary',
				callback	: function(){
					addAnswerQuestion($(this),ownid);
				}
			};
			var ui  = $('#addAnswerQuestionTitleT').clone();
			var no = window.answersheet.getMaxNo();
			ui.find('#itemNoBegin').val(no);
			dialogConfig.body=ui;
			dialog.nonmodal(dialogConfig)
		});

		function addAnswerQuestion($this,ownid){
			var $dialog = $this.data('dialog');

			var beginNo = $dialog.find('#itemNoBegin').val().trim();
			if(!isInt(beginNo)){
				$dialog.find('#itemNoBegin').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('开始题号必须为正整型;');
				return false;
			}
			beginNo = parseInt(beginNo);
			var endNo = $dialog.find('#itemNoEnd').val().trim();
			if(!isInt(endNo)){
				$dialog.find('#itemNoEnd').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('结束题号必须为正整型;');
				return false;
			}
			endNo = parseInt(endNo);

			if(endNo-beginNo<0){
				$dialog.find('#msg').text('结束题号必须大于或者等于开始题号;');
				return false;
			}

			var itemgroup = {
				name:'answerQuestion',
				title:'解答题',
				content:'',
				colNum:0,
				items:[]
			};
			if(ownid){
				itemgroup.id = ownid;
			}
			for(var i=beginNo;i<=endNo;i++){
				itemgroup.items.push({id:answersheet.uuid(),no:i,height:50,content:''});
			}

			answersheet.addItemGroup(itemgroup);

			$.publish('answersheet.reDraw');
			$.publish('ui.itemGroup.info');
			$this.trigger('close');

		}

		$.subscribe('ui.showAddencompositionUI',function(e,ownid){
			var dialogConfig = {};
			dialogConfig.header={text:'+增加英语作文'};
			dialogConfig.footer={buttons:[]};
			dialogConfig.footer.buttons[0]={
				type			: 'button',
				text			: "确定",
				clazz			: 'btn-primary',
				callback	: function(){
					addencomposition($(this),ownid);
				}
			};
			var ui  = $('#addencompositionT').clone();
			dialogConfig.body=ui;
			dialog.nonmodal(dialogConfig)
		});

		function addencomposition($this,ownid){
			var $dialog = $this.data('dialog');

			var rowNum = $dialog.find('#rowNum').val().trim();
			if(!isInt(rowNum)){
				$dialog.find('#rowNum').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('作文行数必须为正整型;');
				return false;
			}
			

			var itemgroup = {
				name:'encomposition',
				title:'英语作文',
				content:'',
				colNum:1,
				rowNum:rowNum,
				items:[]
			};
			if(ownid){
				itemgroup.id = ownid;
			}
			var no = window.answersheet.getMaxNo();
			itemgroup.items.push({no:no});
			itemgroup.height = rowNum*10;
			console.log(itemgroup)
			answersheet.addItemGroup(itemgroup);

			$.publish('answersheet.reDraw');
			$.publish('ui.itemGroup.info');
			$this.trigger('close');

		}


		$.subscribe('ui.showAddcompositionUI',function(e,ownid){
			var dialogConfig = {};
			dialogConfig.header={text:'+增加语文作文'};
			dialogConfig.footer={buttons:[]};
			dialogConfig.footer.buttons[0]={
				type			: 'button',
				text			: "确定",
				clazz			: 'btn-primary',
				callback	: function(){
					addcomposition($(this),ownid);
				}
			};
			var ui  = $('#addcompositionT').clone();
			dialogConfig.body=ui;
			dialog.nonmodal(dialogConfig)
		});

		function addcomposition($this,ownid){
			var $dialog = $this.data('dialog');

			var wordNum = $dialog.find('#wordNum').val().trim();
			if(!isInt(wordNum)){
				$dialog.find('#wordNum').css({'border':'1px solid red;'});
				$dialog.find('#msg').text('作文字数必须为正整型;');
				return false;
			}
			
			var no = window.answersheet.getMaxNo();
			var itemgroup = {
				name:'composition',
				title:'语文作文',
				height:14,
				optionCount:wordNum,
				no:no,
				items:[]
			};
			if(ownid){
				itemgroup.id = ownid;
			}
			answersheet.addItemGroup(itemgroup);

			$.publish('answersheet.reDraw');
			$.publish('ui.itemGroup.info');
			$this.trigger('close');

		}

		$('.addItem').on('click','.addItemBtn',function(){
			var type = $(this).data('type');
			if(type === 'choiceQuestions'){
				$.publish('ui.showAddChoiceQuestionsUI');
			}else if(type === 'fillBlankQuestion'){
				$.publish('ui.showAddFillBlackQuestionsUI');
			}else if(type === 'answerQuestion'){
				$.publish('ui.showAddAnswerQuestionUI');
			}else if(type === 'encomposition'){
				$.publish('ui.showAddencompositionUI');
			}else if(type === 'composition'){
				$.publish('ui.showAddcompositionUI');
			}
		});

		return {
			
		};


	});
})();