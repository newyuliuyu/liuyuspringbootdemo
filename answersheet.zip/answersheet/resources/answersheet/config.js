(function() {
	"use strict";
	var plugins = ['A4','A32','A33','choiceQuestions',
					'fillBlankQuestion','answerQuestion','encomposition',
					'fillBlankTitle','textTitle','composition'];


	var plugins2 = [];
	$.each(plugins,function(idx,item){
		plugins2.push('answersheet/plugin/'+item);
	});
	define(plugins2, function() {
		
		var myPlugins={};
		var size  = plugins.length;
		for(var i=0;i<size;i++){
			myPlugins[plugins[i]] = arguments[i];
		}
		return {plugin:myPlugins};
			
	});
})();