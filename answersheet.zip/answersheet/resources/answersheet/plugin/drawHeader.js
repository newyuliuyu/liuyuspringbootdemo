(function() {
	"use strict";
	var models = ['jquery'];

	define(models, function($) {
		
		var answersheet  = undefined;
		var $pageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop = 0;
		var unit = undefined;

		var pageData = undefined;
		var pageInfo = undefined;


		var pageTitleHeight = 20; 
		var $headerContent = undefined;
		var headerContentHeight = 88; 

		function answersheetTitle(){

			var html = '<div style="position:absolute;padding:0px;"></div>';
			var $titleDiv=$(html);
			$titleDiv.css({
				'width':contentWith+unit,
				'top':0+unit,
				'left':0+unit
			});

			var $textarea  = $('<textarea/>',{'class':'answersheetTitle',css:{
				'position':'absolute',
				'border': 'none',
    			'padding': '0px',
				'line-height': 10+unit,
				'font-size': 10+unit,
				'text-align': 'center',
				'resize':'none',
				'width':contentWith+unit,
				'height':pageTitleHeight+unit,
				'top':0+unit,
				'left':0+unit,
				'overflow': 'hidden'
			}}).text(pageData.answersheetName);
			$titleDiv.append($textarea);
			$pageBody.append($titleDiv);

			$textarea.on('keyup',function(){
				var values = $(this).val().split('\n');
				if(values.length>2){
					$(this).val(values[0]+'\n'+values[1]);
				}
			});

		}


		function drawHeaderContent(){
			var html='<div  style="position: absolute;border: 1px solid gray;"></div>';
			var top = pageTitleHeight+2;
			var left  = 0;
			headerContentHeight = 87;
			$headerContent  = $(html);
			$headerContent.css({
				top:top+unit,
				left:0+unit,
				width:contentWith+unit,
				height:headerContentHeight+unit
			});

			$pageBody.append($headerContent);
		}


		function createStudentInfo(){
			var html = '<div id="studentInfo" contenteditable="true" style="position: absolute;text-align: left;"></div>';
			var $s = $(html);
			$s.css({
				top:0+unit,
				left:0+unit,
				width:80+unit,
				height:30+unit
			});

			if(answersheet.debug){
				$s.css({'border': '1px solid;'});
			}

			html='<p style="line-height: 10mm;padding: 0px;margin: 0px;">\
						<span style="font-family: SimSun;">姓名:</span><u style="text-decoration: underline;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u>\
					</p>\
					<p style="line-height: 10mm;padding: 0px;margin: 0px;">\
						<span style="font-family: SimSun;">学校:</span><u style="text-decoration: underline;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u>\
					</p>\
					<p style="line-height: 10mm;padding: 0px;margin: 0px;">\
						<span style="font-family: SimSun;">班级:</span><u style="text-decoration: underline;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u>\
					</p>';
			$s.append(html);
			$headerContent.append($s);
		}


		function createTeacherWrite(){
			var html = '<div style="position: absolute;line-height: 12mm; text-align: left;"></div>';
			var $s = $(html);
			$s.css({
				top:30+unit,
				left:0+unit,
				width:80+unit,
				height:12+unit
			});
			if(answersheet.debug){
				$s.css({'border': '1px solid;'});
			}
			html='<div style="position: absolute;top:0mm;left:0mm;width: 18mm;font-family: SimSun;border: none;">正确填涂</div>\
					<div style="position: absolute;top:5mm;left:20mm;width: 4mm;height: 2mm;background-color: #000;"></div>\
					<div style="position: absolute;top:0mm;left:26mm;width: 10mm;font-family: SimSun;border: none;">违纪</div>\
					<div style="position: absolute;top:5mm;left:40mm;width: 4mm;height: 2mm;background-color: #fff;border: 1px solid;"></div>\
					<div style="position: absolute;top:0mm;left:48mm;width: 10mm;font-family: SimSun;border: none;">缺考</div>\
					<div style="position: absolute;top:5mm;left:62mm;width: 4mm;height: 2mm;background-color: #fff;border: 1px solid;"></div>';
			$s.append(html);
			$headerContent.append($s);
		}

		function createPrecautionsContent(){
			var html='<div  contenteditable="true" style="border:1px solid gray;position: absolute;text-align: left;"></div>';
			var $s = $(html);
			$s.css({
				top:42+unit,
				left:0+unit,
				width:80+unit,
				height:45+unit
			});
			if(answersheet.debug){
				$s.css({'border': '1px solid;'});
			}

			html = '<p style="font-size: 4mm;line-height: 4mm;font-weight: bold;text-align: center;font-family: SimSun;font-weight:bold;margin: 0px;padding: 0px;">注意事项</p>\
					<p style="font-size: 3mm;line-height: 4mm;text-align: left;margin: 0px;padding: 0px;font-family: SimSun;">\
						 1．答题前，考生先将自己的姓名、班级、座位号填写清楚，并认真核对条形码上的姓名和准考证号。<br />\
						 2．选择题部分请按题号用2B铅笔填涂方框，修改时用橡皮擦干净，不留痕迹。<br />\
						 3．非选择题部分请按题号用0.5毫米黑色墨水签字笔书写，否则作答无效。要求字体工整、笔迹清晰。作图时，必须用2B铅笔，并描浓。<br />\
						 4．在草稿纸、试题卷上答题无效。<br />\
						 5．请勿折叠答题卡,保持字体工整、笔迹清晰、卡面清洁。<br />\
					</p>';
			$s.append(html);
			$headerContent.append($s);
		}


		function createzkzh(){
			var html='<div style="position: absolute;"></div>';
			var $s = $(html);
			var left  = 80;
			var width = contentWith-left;
			var height = 87;
			$s.css({
				top:0+unit,
				left:left+unit,
				width:width+unit,
				height:height+unit
			});
			if(answersheet.debug){
				$s.css({'border': '1px solid;'});
			}
			$headerContent.append($s);


			if(pageData.isBarcode){
				barcode($s,width,height);
			}else{
				noBarcode($s,width,height)
			}
		}

		function noBarcode($zkzh,_width,_height){
			var perWidth = 8;
			var zkzhNum = pageData.zkzhNumber;
			var allWidth = perWidth* zkzhNum;
			var initLeft  = (_width/2)-(allWidth/2);
			var top = (87/2)-(70/2);






			var html  = '<div style="position: absolute;text-align: center;font-family: SimSun;font-size: 4mm;border: 1px solid gray;">准考证号</div>';
			var $html = $(html);
			$html.css({
				top:top+unit,
				left:initLeft+unit,
				width:allWidth+unit,
				height:5+unit
			});
			$zkzh.append($html);
			top+=5;

			for(var i=1;i<=zkzhNum;i++){
				html  = '<div style="position: absolute;font-size: 4mm;"></div>';
				$html = $(html);
				$html.css({
					top:top+unit,
					left:(initLeft+((i-1)*perWidth))+unit,
					width:perWidth+unit,
					height:5+unit,
					'border-left': '1px solid gray',
					'border-bottom': '1px solid gray'
				});
				if(i === zkzhNum){
					$html.css({
						'border-right': '1px solid gray'
					});
				}
				$zkzh.append($html);
			}
			top+=5;
			var perHeight = 6;
			for(var i=0;i<10;i++){
				for(var j=0;j<zkzhNum;j++){
					html  = '<div style="position: absolute;font-size: 5mm; font-family: HYT_OMR_Big;text-align:center;"></div>';
					$html = $(html);
					$html.css({
						top:top+unit,
						left:(initLeft+(j*perWidth))+unit,
						width:perWidth+unit,
						height:perHeight+unit,
						'line-height': perHeight+unit,
						'border-left': '1px solid gray'
					});
					$html.text(i);
					if(j+1 === zkzhNum){
						$html.css({
							'border-right': '1px solid gray'
						});
					}
					if(i === 9){
						$html.css({
							'border-bottom': '1px solid gray'
						});
					}
					$zkzh.append($html);
				}
				top+=perHeight;
			}

		}

		function barcode($zkzh,_width,_height){
			var html  = '<div style="position: absolute;border: 1px dashed gray;">\
						<p style="padding: 5mm; text-align: center;font-size: 6mm;color: gray;">贴条形码区</p>\
						<p style="text-align: center;font-size: 3mm;color: gray;">（正面朝上，切勿贴出虚线方框）</p>\
					</div>';

			var height = 27;
			var width=63;
			var left  = (_width/2)-(width/2);
			var top  = (_height/2)-(height/2);
			var $html = $(html);
			$html.css({
				top:top+unit,
				left:left+unit,
				width:width+unit,
				height:height+unit
			});
			$zkzh.append($html);
		}

		function draw(){
			answersheetTitle();
			drawHeaderContent();
			createStudentInfo();
			createTeacherWrite();
			createPrecautionsContent();
			createzkzh();
		}

		function init(){
			contentWith = answersheet.toMM($pageBody.width());
		    contentHeight = answersheet.toMM($pageBody.height());

			pageData = answersheet.data.page;
			pageInfo = answersheet.pageInfo;
			unit = pageData.unit;
		}


		return {
			draw : function(_answersheet,_$pageBody){
				answersheet = _answersheet;
				$pageBody = _$pageBody;
				init();
				draw();
				return headerContentHeight+pageTitleHeight+4;
			}
		};
			
	});
})();