(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {

		var itemGroup = undefined;
		var answersheet = undefined;
		var $curPageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop = undefined;

		var unit=undefined;
		
		function createContent(){
			var height  = itemGroup.height;
			var totalRow  = getTotalRow();
			return createContent2(height,0,1,totalRow);
		}

		function createContent2(height,idx,beginRow,totalRow){

			if(contentTop+height > contentHeight){
				var contentLaveHeight  = contentHeight-contentTop;
				var realHeight  = height - contentLaveHeight;
				var itemPosition = getItemPosition(beginRow,contentLaveHeight,totalRow);
				createItem(idx,contentWith,contentTop,contentLaveHeight,itemPosition);

				$curPageBody.data('end',contentHeight);
				answersheet.nextPage();
				init(answersheet)

				return createContent2(realHeight,idx+1,itemPosition.endRow);

			}else{
				var itemPosition = getItemPosition(beginRow,height,totalRow);
				return createItem(idx,contentWith,contentTop,height,itemPosition);
			}
		}

		function getTotalRow(){
			return itemGroup.rowNum;
		}

		function getItemPosition(beginRow,height,totalRow){
			var row = (height/10).toFixed2(0);
			var endRow  = beginRow+row;
			return {
				beginRow:beginRow,
				endRow:endRow
			}
		}

		function createItem(idx,width,top,height,itemPosition){
			console.log(itemPosition)
			var  html = '<div class="editItem" contenteditable="true" style="padding:0px;padding-top:3mm;left:0mm;text-align: left;border: 1px solid gray;position: absolute;"></div>';
			var $content = $(html).css({
				width:width+unit,
				top:top+unit,
				height:height+unit
			}).attr('ownId',itemGroup.id);
			$content.data('itemType','encomposition');
			$content.data('idx',idx);
			
			var content = answersheet.getItemGroupContent(itemGroup.id);
			//createItemContent($content,itemPosition);
			if(content.length === 0){
				createItemContent($content,itemPosition);
			}else{
				createItemContent2($content,itemPosition);
			}

			var editor  = CKEDITOR.inline($content[0]);
			$content.blur(function(){
				getContent(itemGroup.id);
			});
			$curPageBody.append($content);
			return $content;
		}

		function getContent(ownId){
			var $contents = $('div.editItem[ownid="'+ownId+'"]');
			var content = '';
			$contents.each(function(idx,item){
				if(idx==0){
					content+=$(this).html();
				}else{
					content+='<br>'+$(this).html();
				}
			});
			var c = answersheet.getItemGroupContent(ownId);
			if(c !== content){
				answersheet.setItemGroupContent(ownId,content);
			}
		}

		function createItemContent2($content,itemPosition){
			var contents = answersheet.getItemGroupContent(itemGroup.id).split('<br>');
			var beginRow  = itemPosition.beginRow;
			beginRow-=1;
			var endRow  = itemPosition.endRow;
			endRow-=1;
			var c = contents.slice(beginRow,endRow);
			$content.append(c.join('<br>'));
		}

		function getRowSpaceNum(){
			var num = 48;
			if(answersheet.data.page.pageName ==='A33'){
				num=33;
			}
			return num;
		}

		function createItemContent($content,itemPosition){
			var spaceNum = getRowSpaceNum();
			var space = new Array();
			for(var i=0;i<spaceNum;i++){
				space.push('&nbsp;');
			}
			var item = itemGroup.items[0];
			var beginRow  = itemPosition.beginRow;
			beginRow-=1;
			var endRow  = itemPosition.endRow;
			endRow-=1;
			for(var i=beginRow;i<endRow;i++){
				var kk ='';
				if(i===beginRow){
					kk = item.no+'.';
					var spaceStr = "";
					if(answersheet.data.page.pageName ==='A33'){
						spaceStr = space.slice(0,31).join("");
					}else{
						spaceStr = space.slice(0,46).join("");
					}

					kk += '&nbsp;<span style="line-height: 10mm;"><u>'+spaceStr+'</u></span><br>';
				}else{
					kk += '&nbsp;<span style="line-height: 10mm;"><u>'+space.join("")+'</u></span><br>';
				}
				$content.append(kk)
			}
		}


		function create(){
			var $content = createContent();
			var top  = $content.position().top;
			top  = answersheet.toMM(top);
			var height = $content.height();
			height  = answersheet.toMM(height);
			$curPageBody.data('end',top+height+2);
		}

		function init(_answersheet){
			answersheet = _answersheet;
			$curPageBody = answersheet.getCurPageBody();
			contentWith =  answersheet.getPageBodyWith();
			contentHeight = answersheet.getPageBodyHeight();
			unit  = answersheet.getUnit();
			contentTop = $curPageBody.data('end');
		}

		return {
			create:function(_answersheet,_itemGroup){
				_answersheet.createTextTitle(_itemGroup.title,_itemGroup.id);
				itemGroup =_itemGroup;
				init(_answersheet);
				create();
			}
		}
	});
})();