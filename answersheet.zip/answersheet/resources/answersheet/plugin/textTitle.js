(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {

		var answersheet = undefined;
		var $curPageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop = undefined;
		var titleName = undefined;
		var ownId = undefined;

		var unit=undefined;
		

		function createTitle(){
			var height = 4;
			if(contentTop+height>contentHeight){
				answersheet.nextPage();
				init(answersheet);
			}

			var  html = '<div style="padding: 0px;left:0mm;border: none;position: absolute;"></div>';
			var $content = $(html).css({
				width:contentWith+unit,
				top:contentTop+unit,
				height:height+unit
			}).attr('ownId',ownId);
			$curPageBody.append($content);




			html='<textarea style="padding: 0px;line-height: 4mm;height: 4mm;text-align: left;font-weight: bold;resize:none;font-size: 3mm;overflow:hidden;border: none;"></textarea>';
			var $title = $(html).text(titleName);
			$title.css({
				width:contentWith+unit
			});
			$content.append($title);
			$title.blur(function(){
				var parent  = $(this).parent();
				var ownId  = parent.attr('ownid');
				var title  = $(this).val();
				answersheet.setItemGroupTitle(title,ownId);
			});
		}





		function create(){
			createTitle();
			$curPageBody.data('end',contentTop+6);
		}

		function init(_answersheet){
			answersheet = _answersheet;
			$curPageBody = _answersheet.getCurPageBody();
			contentWith =  _answersheet.getPageBodyWith();
			contentHeight = _answersheet.getPageBodyHeight();
			unit  = _answersheet.getUnit();
			contentTop = $curPageBody.data('end');
		}

		return {
			create:function(_answersheet,_titleName,_ownId){
				titleName =_titleName;
				ownId = _ownId;
				init(_answersheet);
				
				create();
			}
		}
	});
})();