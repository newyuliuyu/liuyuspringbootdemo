(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {

		var itemGroup = undefined;
		var answersheet = undefined;
		var $curPageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop = undefined;

		var unit=undefined;
		
		function createContent(){
			var height  = itemGroup.height;
			return createContent2(height,0);
		}

		function createContent2(height,idx){

			if(contentTop+height > contentHeight){
				var contentLaveHeight  = contentHeight-contentTop;
				var realHeight  = height - contentLaveHeight;
				createItem(contentWith,contentTop,contentLaveHeight);

				$curPageBody.data('end',contentHeight);
				answersheet.nextPage();
				init(answersheet)

				return createContent2(realHeight,idx+1);

			}else{
				return createItem(contentWith,contentTop,height);
			}
		}

		function createItem(width,top,height){
			var  html = '<div class="editItem" contenteditable="true" style="padding: 0px;left:0mm;text-align: left;border: 1px solid;position: absolute;"></div>';
			var $content = $(html).css({
				width:width+unit,
				top:top+unit,
				height:height+unit
			}).attr('ownId',itemGroup.id);
			$content.append('1.&nbsp;<span style="line-height:10mm;font-family:SimSun-ExtB, NSimSun;font-size:12px;"><u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></span>');
			
			CKEDITOR.inline($content[0]);

			$curPageBody.append($content);


			return $content;
		}


		function create(){
			var $content = createContent();
			var top  = $content.position().top;
			top  = answersheet.toMM(top);
			var height = $content.height();
			height  = answersheet.toMM(height);
			$curPageBody.data('end',top+height+2);
		}

		function init(_answersheet){
			answersheet = _answersheet;
			$curPageBody = answersheet.getCurPageBody();
			contentWith =  answersheet.getPageBodyWith();
			contentHeight = answersheet.getPageBodyHeight();
			unit  = answersheet.getUnit();
			contentTop = $curPageBody.data('end');
		}

		return {
			create:function(_answersheet,_itemGroup){
				_answersheet.createTextTitle(_itemGroup.title,_itemGroup.id);
				itemGroup =_itemGroup;
				init(_answersheet);
				create();
			}
		}
	});
})();