(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {

		var itemGroup = undefined;
		var answersheet = undefined;
		var $curPageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop = undefined;

		var unit=undefined;
		
		function createContent(){
			var items = itemGroup.items;
			var $content = undefined;
			$.each(items,function(idx,item){
				$content = createContent2(item,item.height,0,1);
			});
			return $content;
		}

		function createContent2(item,height,idx,beginRow){
			if(contentTop+height > contentHeight){
				var contentLaveHeight  = contentHeight-contentTop;
				var realHeight  = height - contentLaveHeight;
				var itemPosition = getItemPosition(beginRow,contentLaveHeight);
				createItem(item,idx,contentWith,contentTop,contentLaveHeight,itemPosition);

				$curPageBody.data('end',contentHeight);
				answersheet.nextPage();
				init(answersheet)

				return createContent2(item,realHeight,idx+1,itemPosition.endRow);

			}else{
				var itemPosition = getItemPosition(beginRow,height);
				var $content = createItem(item,idx,contentWith,contentTop,height,itemPosition);
				contentTop=contentTop+height;
				return $content;
			}
		}

		function getTotalRow(){
			var colNum = itemGroup.colNum;
			var items = itemGroup.items;
			var itemSize  = items.length;
			var row  = Math.ceil(itemSize/colNum);
			if(itemSize%colNum !== 0){
				row+=1;
			}
			
			return row;
		}

		function getItemPosition(beginRow,height){
			var row = (height/10).toFixed2(0);
			var endRow  = beginRow+row;
			return {
				beginRow:beginRow,
				endRow:endRow
			}
		}

		function createItem(item,idx,width,top,height,itemPosition){
			var  html = '<div class="editItem" contenteditable="true" style="padding: 0px;left:0mm;text-align: left;border: 1px solid gray;position: absolute;"></div>';
			var $content = $(html).css({
				width:width+unit,
				top:top+unit,
				height:height+unit
			}).attr('ownId',item.id);
			$content.data('itemType','answerQuestion');
			$content.data('item',item.no);
			$content.data('idx',idx);

			var content = getItemContent(item.id);
			//createItemContent($content,itemPosition);
			if(content.length === 0 && idx===0){
				createItemContent($content,item,itemPosition);
			}else if(content.length > 0){
				createItemContent2(item,$content,itemPosition);
			}
			$content.blur(function(){
				setContent(item.id);
			});
			var editor  = CKEDITOR.inline($content[0]);
			$curPageBody.append($content);
			return $content;
		}

		function setContent(ownId){
			var $contents = $('div.editItem[ownid="'+ownId+'"]');
			var content = '';
			$contents.each(function(idx,item){
				if(idx==0){
					content+=$(this).html();
				}else{
					content+='<br>'+$(this).html();
				}
			});
			var c = getItemContent(ownId);
			if(c !== content){
				answersheet.setItemContent(itemGroup.id,ownId,content);
			}
		}

		function getItemContent(itemId){
			var item  = answersheet.getItem(itemGroup.id,itemId);
			return item.content;
		}

		function createItemContent2(item,$content,itemPosition){
			var contents = item.content.split('<br>');
			var beginRow  = itemPosition.beginRow;
			beginRow-=1;
			var endRow  = itemPosition.endRow;
			endRow-=1;
			var c = contents.slice(beginRow,endRow);
			$content.append(c.join('<br>'));
		}

		function createItemContent($content,item,itemPosition){
			$content.append(item.no+'.');
		}


		function create(){
			var $content = createContent();
			var top  = $content.position().top;
			top  = answersheet.toMM(top);
			var height = $content.height();
			height  = answersheet.toMM(height);
			$curPageBody.data('end',top+height+2);
		}

		function init(_answersheet){
			answersheet = _answersheet;
			$curPageBody = answersheet.getCurPageBody();
			contentWith =  answersheet.getPageBodyWith();
			contentHeight = answersheet.getPageBodyHeight();
			unit  = answersheet.getUnit();
			contentTop = $curPageBody.data('end');
		}

		return {
			create:function(_answersheet,_itemGroup){
				_answersheet.createTextTitle(_itemGroup.title,_itemGroup.id);
				itemGroup =_itemGroup;
				init(_answersheet);
				create();
			}
		}
	});
})();