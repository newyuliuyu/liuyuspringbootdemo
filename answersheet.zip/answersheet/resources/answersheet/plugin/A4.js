(function() {
	"use strict";
	var models = ['jquery','answersheet/plugin/drawHeader'];

	define(models, function($,drawHeader) {
		
		var answersheet=undefined;

		var pageHTML = '<div class="page" style="position:relative;display:inline-block;margin:50px 0px;padding:0px;background-color:#fff;"></div>';
		var pageBodyHTML = '<div class="pageBody" style="position:absolute;padding:0px;"></div>';
	

		var pageInfo=undefined;
		var pageData=undefined;

		function initData(){
			pageInfo={
				pages:new Array(),
				pageBodys:new Array()
			}

			pageData={
				pageName:'A4',
				width:210,
				height:297,
				unit:'mm',
				cols:1,
				answersheetName:'',
				zkzhNumber:6,
				studentInfoContent:'',
				precautionsContent:'',
				isBarcode:false
			};
		}


		function createPage(){
			var $page = $(pageHTML);
			$page.css({
				width:pageData.width+pageData.unit,
				height:pageData.height+pageData.unit
			});
			answersheet.body.append($page);
			pageInfo.pages.push($page);
			return $page;
		}

		function initPX(){
			var $page = pageInfo.pages[0];
			answersheet.px = $page.width()/pageData.width;
		}

		function createBlcok($page){
			var myPosition={LT:1,RT:2,LB:3,RB:4}
			var baseTop = 11;
			var baseLeft = 6;
			var pageWidth=pageData.width;
			var pageHeight = pageData.height;
			var unit = pageData.unit;
			var width = 5;
			var height = 5;
			
			function oneBlock(position){
					
				var top = 0;
				var left = 0;
				if(position === myPosition.LT){
					top =baseTop;
					left = baseLeft;
				}else if(position === myPosition.RT){
					top =baseTop;
					left = pageWidth-baseLeft-width;
				}else if(position === myPosition.LB){
					top =pageHeight-baseTop-height;
					left = baseLeft;
				}else if(position === myPosition.RB){
					top =pageHeight-baseTop-height;
					left =  pageWidth-baseLeft-width;
				}

				var $block = $('<div>',{css:{
					'background-color':'#000',
					'display':'inline-block',
					'position':'absolute',
					'width':width+pageData.unit,
					'height':height+pageData.unit,
					'top':top+unit,
					'left':left+unit
				}});
				$page.append($block);
			}
			oneBlock(myPosition.LT);
			oneBlock(myPosition.RT);
			oneBlock(myPosition.LB);
			oneBlock(myPosition.RB);	
		}

		function createPageBody($page){
			var $pageBody = $(pageBodyHTML);
			var unit  = pageData.unit;
			var left  = 15;
			var top = 20;
			var  width =pageData.width-left*2;
			var height = pageData.height-top*2;

			$pageBody.css({
				left:left+unit,
				top:top+unit,
				width:width+unit,
				height:height+unit
			});
			if(answersheet.debug){
				$pageBody.css({'border': '1px solid;'});
			}

			$pageBody.data('end',0);
			$page.append($pageBody);
			pageInfo.pageBodys.push($pageBody);
			return $pageBody;
		}

		



		function create(){
			var $page = createPage();
			initPX();
			createBlcok($page);
			var $pageBody = createPageBody($page);
			var end  = drawHeader.draw(answersheet,$pageBody);
			$pageBody.data('end',end);
			pageInfo.curPageBodyIdx = pageInfo.pageBodys.length-1;
		} 		

		function newPage(){
			var $page = createPage();
			createBlcok($page);
			var $pageBody = createPageBody($page);
			if(pageInfo.pages.length%2 === 1){
				var  end = drawHeader.draw(answersheet,$pageBody);
				$pageBody.data('end',end);
			}
	
			pageInfo.curPageBodyIdx = pageInfo.pageBodys.length-1;
		}

		function reDrawPage(){
			//var $pageBody = answersheet.getCurPageBody();
			
			var pageBodySize  = pageInfo.pageBodys.length;
			for(var i=0;i<pageBodySize;i+=2){
				var $pageBody = pageInfo.pageBodys[i];
				var end = drawHeader.draw(answersheet,$pageBody);
				$pageBody.data('end',end);
			}
			pageInfo.curPageBodyIdx = 0;
		}


		return {
			createPage:function(_answersheet){
				answersheet=_answersheet;
			    initData();
				if($.isPlainObject(answersheet.data.page)){
					$.extend(pageData,answersheet.data.page);
				}
				if($.isPlainObject(answersheet.pageInfo)){
					$.extend(pageInfo,answersheet.pageInfo);
				}
				answersheet.data.page = pageData;
				answersheet.pageInfo = pageInfo;
				create();
			},
			newPage : function(_answersheet){
				answersheet=_answersheet;
				initData();
				if($.isPlainObject(answersheet.data.page)){
					$.extend(pageData,answersheet.data.page);
				}
				if($.isPlainObject(answersheet.pageInfo)){
					$.extend(pageInfo,answersheet.pageInfo);
				}
				answersheet.data.page = pageData;
				answersheet.pageInfo = pageInfo;
				newPage();
			},
			reDrawPage:function(_answersheet){
				_answersheet.pageInfo.curPageBodyIdx = 0;
				initData();
				answersheet=answersheet;
				if($.isPlainObject(answersheet.data.page)){
					$.extend(pageData,answersheet.data.page);
				}
				if($.isPlainObject(answersheet.pageInfo)){
					$.extend(pageInfo,answersheet.pageInfo);
				}
				answersheet.data.page = pageData;
				answersheet.pageInfo = pageInfo;
				reDrawPage();
			}

		};
			
	});
})();