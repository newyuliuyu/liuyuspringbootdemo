(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {

		var meItemGroup = undefined;
		var meAnswersheet = undefined;
		var $curPageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop  = undefined; 
		var idx = 0;
		var unit=undefined;
		
		function createContent(){
			var  html = '<div class="editItem choiceItem"  style="padding: 0px;left:0mm;border: 1px solid gray;position: absolute;"></div>';
			var $content = $(html).css({
				width:contentWith+unit,
				top:contentTop+unit,
				height:100
			}).attr('ownId',meItemGroup.id);
			$content.data('itemType','choiceQuestions');
			$content.data('idx',idx);
			$curPageBody.append($content);
			return $content;
		}

		function getContentTop($content){
			var contentTop = $content.position().top;
			contentTop = meAnswersheet.toMM(contentTop);
			return contentTop;
		}
		function createChoiceQuestions($content){

			var items = meItemGroup.items;
			/**基本宽度**/
			var baseWidth = 7;
			var itemSize = items.length;
			/**基本高度**/
			var lineHeight = 5;
			var tmpItems = new Array();
			var groupCount = 0;
			var top = 6;
			var left  = 0;
			var maxOptinoCount = 4;
			var maxHeight  =  0;


			$.each(items,function(idx,item){
				tmpItems.push(item);
				maxOptinoCount=item.optionCount;
				/**是否需要画内容**/
				var isCreate = false;
				/**如果下一个选择题与当前一个选择题内容不相同就需要话**/
				if(idx+1 < itemSize){
					var nextItem  = items[idx+1];
					if(nextItem.optionCount !== maxOptinoCount){
						isCreate = true;
					}
				}
				/**如果该题有5个或者最后一个就画选择题**/
				if(tmpItems.length === 5 || (idx+1) == itemSize ){
					isCreate = true;
				}
				

				if(isCreate){
					/**计算选择题宽度和高度**/
					var width = (maxOptinoCount+1)*baseWidth;
					var height  = lineHeight*tmpItems.length;
					/**如果选择题需要画的宽度大于能存放的宽度就换行话**/
					if(left+width > contentWith){
						top+=height+3;
						left=0;
					}
					/**如果需要画的内容高度大于了可以存放内容的高度就换页**/
					if((contentTop+top+height)>contentHeight){
						$content.height((contentHeight-contentTop)+unit);
						$curPageBody.data('end',contentHeight);

						meAnswersheet.nextPage();
						init(meAnswersheet);
						/****/
						idx++;
						$content = createContent();
						contentTop = getContentTop($content);
						left = 0;
						top=0;
					}
					/**画一组选择题**/
					createOneGroup(left,top,width,height,lineHeight,baseWidth,tmpItems,$content);
					/**计算画选做题的高度**/
					if(height > maxHeight){
						maxHeight = height;
					}
					/**重新初始化，准备下一组，并且增加left的位置**/
					tmpItems = new Array();
					left+=width+baseWidth;
				}

			});

			$content.height((top+maxHeight+3)+unit);


			$curPageBody.data('end',contentTop+top+maxHeight+3+2);
		}

		function createOneGroup(left,top,width,height,lineHeight,baseWidth,items,$content){
			var html = '<div style="position: absolute;padding: 0px;margin: 0px; border: none;"></div>';
			var $group = $(html);
			$group.css({
				top:top+unit,
				left:left+unit,
				height:height+unit,
				width:width+unit,
				'line-height':lineHeight+unit,
			});

			var OPTION=["A","B","C","D","E","F","G","H","I","J","K","M","N"];
			$.each(items,function(idx,item){
				var left  = 0;
				var top = idx*lineHeight;

				var html='<span style="border:none; position: absolute;display: inline-block;text-align: right; vertical-align:middle; font-size: 3mm;"></span>';
				var $item = $(html);
				$item.css({
					top:top+unit,
					left:left+unit,
					width:baseWidth+unit,
					height:lineHeight+unit
				}).html(item.no+'&nbsp;');
				$group.append($item);

				for(var i=0;i<item.optionCount;i++){
					html='<span style="border:none; position: absolute;display: inline-block;vertical-align:middle;font-size: 5mm; font-family: HYT_OMR_Big;"></span>';
					left=(i+1)*baseWidth;
					$item = $(html);
					$item.css({
						top:top+unit,
						left:left+unit,
						width:baseWidth+unit,
						height:lineHeight+unit
					}).html(OPTION[i]);

					$group.append($item);
				}
			});
			$content.append($group);
		}


		function create(){
			var $content = createContent();
			createChoiceQuestions($content);
		}

		function init(answersheet){
			meAnswersheet = answersheet;
			$curPageBody = answersheet.getCurPageBody();
			contentWith =  meAnswersheet.getPageBodyWith();
			contentHeight = meAnswersheet.getPageBodyHeight();
			contentTop = $curPageBody.data('end');
		}
		return {
			create:function(answersheet,itemGroup){
				answersheet.createTextTitle(itemGroup.title,itemGroup.id);
				meItemGroup =itemGroup;
				init(answersheet);
				unit  = meAnswersheet.getUnit();
				create();
			}
		}
	});
})();