(function() {
	"use strict";
	var models = ['jquery'];
	define(models, function($) {

		var itemGroup = undefined;
		var answersheet = undefined;
		var $curPageBody = undefined;
		var contentWith = undefined;
		var contentHeight = undefined;
		var contentTop = undefined;
		var unit=undefined;
		var $compostion  = undefined;
		var idx = 0;
		function checkHeight(){
			if(contentTop+itemGroup.height+9.5>contentHeight){
				answersheet.nextPage();
				init(answersheet);
			}
		}
		function createCompositionDIV(){
			checkHeight();
			var  html = '<div class="editItem" style="padding: 0px;left:0mm;text-align: left;position: absolute;border: 1px solid gray;"></div>';
			$compostion = $(html).css({
				width:contentWith+unit,
				top:contentTop+unit,
				height:itemGroup.height+unit
			}).attr('ownId',itemGroup.id);
			$compostion.data('itemType','composition');
			$compostion.data('idx',idx);
			$curPageBody.append($compostion);
		}

		function createEdit(){
			var  html = '<div contenteditable="true" style="position: absolute;padding: 0px;left:0mm;text-align: left;"></div>';
			var $edit = $(html).css({
				width:contentWith+unit,
				top:0+unit,
				height:itemGroup.height+unit
			}).attr('ownId',itemGroup.id);



			$compostion.append($edit);
			CKEDITOR.inline($edit[0]);
			
		}

		function createFrame(){
			var top = itemGroup.height+1.5;
			var left = 1;
			var optionCount=itemGroup.optionCount;
			var colNum = (contentWith-2)/7.5;
			colNum = Math.floor(colNum);
			if((contentWith-2)%7.5 !== 0){
				var v = (contentWith-2)%7.5/2;
				left+=v;
			}

			var rowNum = optionCount/colNum;
			rowNum = Math.floor(rowNum);
			if(optionCount%colNum !== 0){
				rowNum+=1;
			}

			for(var i=1;i<=rowNum;i++){
				var myLeft  = left;
				for(var c=1;c<=colNum;c++){
					createCol(top,myLeft,c,colNum,i);
					myLeft+=7.5;
				}
				top+=8;
				if(checkNextRowExceedHeight(top+1.5) && (i+1<=rowNum)){
					//新建一页
					
					setHeight(top,false);
					answersheet.nextPage();
					init(answersheet);
					idx++;
					createCompositionDIV();
					top=1;
				}else{
					createSplit(top,left,colNum);
					top+=1.5;			
				}
			}
			setHeight(top,true);
		}

		function setHeight(_top,isOver){
			var height  = 0;
			if(isOver){
				height=_top+2;
			}else{
				height = contentHeight-contentTop;
			}
			$compostion.css({
				height:height+unit
			});

			var top  = $compostion.position().top;
			top = answersheet.toMM(top);
			$curPageBody.data('end',top+height+2);
		}



		function checkNextRowExceedHeight(top){
			
			return (contentTop+top+9.5) > contentHeight;
		}

		function createSplit(top,left,colNum){
			var html = '<div style="position: absolute;padding: 0px;border:none;"></div>';
			var myFrame = $(html);
			myFrame.css({
				width:(colNum*7.5)+unit,
				height:1.5+unit,
				top:top+unit,
				left:left+unit,
				//'border-top':'none',
				//'border-bottom':'none'
			});
			$compostion.append(myFrame);
		}

		function createCol(top,left,c,colNum,rowIdx){
			var html = '<div style="position: absolute;padding: 0px;border:1px solid;"></div>';
			var myFrame = $(html);
			myFrame.css({
				width:7.5+unit,
				height:8+unit,
				top:top+unit,
				left:left+unit,
			});
			
			if(c <colNum){
				myFrame.css({
					'border-right':'none'
				});
			}
			var num  = (rowIdx-1)*colNum+c
			if( num%100 === 0){
				html = '<div style="position: absolute;bottom:-10px;font-size:5px; padding: 0px;">'+num+'</div>';
				myFrame.append(html);
			}
			$compostion.append(myFrame);
		}






		
		function create(){
			createCompositionDIV();
			createEdit();
			createFrame();

		}

		function init(_answersheet){
			answersheet = _answersheet;
			$curPageBody = answersheet.getCurPageBody();
			contentWith =  answersheet.getPageBodyWith();
			contentHeight = answersheet.getPageBodyHeight();
			unit  = answersheet.getUnit();
			contentTop = $curPageBody.data('end');
		}

		return {
			create:function(_answersheet,_itemGroup){
				_answersheet.createTextTitle(_itemGroup.title,_itemGroup.id);
				itemGroup = _itemGroup;
				init(_answersheet);
				create();
			}
		}
	});
})();