(function() {
	"use strict";
		
	var models = ['jquery','answersheet/config','answersheet/event','answersheet/method','commons/observer','ckedit/ckeditor'];
	

	define(models, function($,config,event,method) {

		CKEDITOR.disableAutoInline = true;


		CKEDITOR.styleCommand.prototype.exec = function(editor) {
		    editor.focus();
		    if (this.state == CKEDITOR.TRISTATE_OFF) {
		        editor.applyStyle(this.style);
		    } else if (this.state == CKEDITOR.TRISTATE_ON) {
		        var selection = editor.getSelection(),
		            ranges = selection.getRanges(),
		            range = ranges[0];
		        if (range.collapsed) {
		            editor.insertHtml("&#8203");
		            editor.removeStyle(this.style);
		            return;
		        }
		        editor.removeStyle(this.style);
		    }
		};

		
		window.answersheet = {};
		answersheet.body = $('#contentBody'); 
		answersheet.toolbar = $('#toolBar');
		event.onevent(answersheet);
		answersheet.plugin = config.plugin;
		answersheet.nos=[];
		$.extend(answersheet,method);		








		
		// window.data  = answersheet.data =  {};

		// data.page={
		// 	pageName:'A4',
		// 	// width:420,
		// 	// height:297,
		// 	unit:'mm',
		// 	cols:1,
		// 	answersheetName:'2017-2018高三单元测试考试\n语文试卷',
		// 	zkzhNumber:11,
		// 	studentInfoContent:'',
		// 	precautionsContent:'',
		// 	isBarcode:false
		// };

		// //题目定义
		// var itemGroups  = data.page.itemGroups=[];


		// var itemgroup = {
		// 	id:answersheet.uuid(),
		// 	name:'choiceQuestions',
		// 	title:'单项选择题',
		// 	items:[]
		// };
		// for(var i=1;i<=25;i++){
		// 	itemgroup.items.push({no:i,optionCount:4});
		// }
		// // for(var i=1;i<50;i++){
		// // 	itemgroup.items.push({no:i,optionCount:6});
		// // }

		// itemGroups.push(itemgroup);

		// var itemgroup = {
		// 	id:answersheet.uuid(),
		// 	name:'fillBlankTitle',
		// 	title:'填空题',
		// 	no:5,
		// 	height:30,
		// 	content:[]
		// };
		// itemGroups.push(itemgroup);

		// var itemgroup = {
		// 	id:answersheet.uuid(),
		// 	name:'fillBlankTitle',
		// 	title:'简答题',
		// 	no:5,
		// 	height:30
			
		// };
		// itemGroups.push(itemgroup);

		// var itemgroup = {
		// 	id:answersheet.uuid(),
		// 	name:'composition',
		// 	title:'作文',
		// 	no:5,
		// 	optionCount:600,
		// 	height:14
			
		// };
		// itemGroups.push(itemgroup);


		
		function newData(){
			var data={
				pageName:'A4',
				unit:'mm',
				cols:1,
				answersheetName:'',
				zkzhNumber:6,
				studentInfoContent:'',
				precautionsContent:'',
				isBarcode:false,
				itemGroups:[]
			};
			return data;

		}

		
		function init(_paperName,_pageData){

			if(!_pageData){
				_pageData = newData();
				_pageData.answersheetName = _paperName;
			}
			answersheet.data={page:_pageData};
			answersheet.laodJson();
			$.publish('answersheet.new');
		}

		return {
			create : function(_paperName,_pageData){
				init(_paperName,_pageData);
			}
		}

	});
})();