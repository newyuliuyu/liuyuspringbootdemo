(function() {
	"use strict";
		
	var models = ['jquery','commons/observer'];
	

	define(models, function($) {

		var answersheet = {};
		function init(){

			answersheet.body.on('mousemove','.editItem',function(e){

				var $content = $(e.toElement);
				if($content.hasClass('editItem') && $('.toolBar').size() === 0){

					var ownId = $content.attr('ownid');
					var idx = $content.data('idx');
					var size = $('div.editItem[ownid="'+ownId+'"]').size();
					var width  = $content.width();
					width = answersheet.toMM(width);
					var height  = $content.height();
					height = answersheet.toMM(height);
					var top  = $content.position().top;
					top = answersheet.toMM(top);
					

					if(size===1 || idx===0){
			
						var html = '<div class="toolBar glyphicon glyphicon-plus" \
						style="border:1px solid #fff; position:absolute;height:5mm; \
						width: 5mm;color: gray;vertical-align: middle;text-align: center;font-size: 5mm;cursor: \
						pointer;"></div>';
						var $add = $(html);
						$add.data('content',$content);
						$add.click(addItemGroup);
						$content.append($add);
						$add.css({
							top:(top+1)+'mm',
							left:(width-12)+'mm'
						}).data('ownId',ownId);
						$content.parent().append($add);

						html = '<div class="toolBar glyphicon glyphicon-remove"  style="position:absolute;\
						border:1px solid #fff; right:0mm;top:0mm;height:5mm;width: 5mm;color: gray;font-size: 5mm;\
						cursor: pointer;"></div>';
						var $delete = $(html);
						$delete.data('content',$content);
						$delete.click(deleteItemGroup);
						$delete.css({
							top:(top+1)+'mm',
							left:(width-6)+'mm'
						}).data('ownId',ownId);
						$content.parent().append($delete);
					}
					if(!$content.hasClass('choiceItem') && (size===1 || idx>0)){
						html = '<div class="toolBar move glyphicon glyphicon-resize-vertical" \
						style="border:1px solid #fff; position:absolute;right: 0mm;bottom: 0mm;height:5mm;\
						width: 8mm;color: gray;font-size: 5mm;cursor: n-resize;"></div>';
						var $move = $(html);
						$move.data('content',$content);
						$move.css({
							top:(top+height-3)+'mm',
							left:(width-10)+'mm'
						}).data('ownId',ownId);
						$content.parent().append($move);
					}
				}
				//e.stopPropagation();
				//return false;
			});

			function deleteItemGroup(e){
				var parents  = $(this).data('content');
				var ownid = parents.attr('ownid');
				var itemType  = parents.data('itemType');

				answersheet.deleteItemGroup(ownid,itemType);
				$.publish('answersheet.reDraw');
				$.publish('ui.itemGroup.info');
				e.stopPropagation();
				return false;
			}

			function addItemGroup(e){
				var parents  = $(this).data('content');
				var ownid = parents.attr('ownid');
				if(parents.hasClass('choiceItem')){
					$.publish('ui.showAddChoiceQuestionsUI',ownid);
				}
				e.stopPropagation();
				return false;
			}

			answersheet.body.on('mouseout','.editItem',function(e){

				//return false;
				var $content = $(e.toElement);
				if($content.hasClass('toolBar')){
					e.stopPropagation();
					return false;
				}

				$content = $(e.toElement);
				var ownId = $content.attr('ownid');
				if(!ownId){
					var $editItem = $content.parents('.editItem');
					ownId = $editItem.attr('ownid');
				}
				var ownId2 = $('.toolBar').data('ownId');

				if(ownId2 != ownId){
					$content = $(e.currentTarget);
					$('.toolBar').remove();
				}
				//!$content.hasClass('editItem') && $editItem.size()==0
				//e.stopPropagation();
				//return false;
			});

			

			function documentMouseMove(e){
				var $target  = $('body');
				var isMove=$target.data('move');
				
				if(isMove){

					var curY =e.pageY;
					var y = $target.data('y');
					var cha = curY - y;
					var $parent = $target.data('parent');
					var height = $parent.height();
					var height2 = height+cha;
					$parent.height(height2);

					var pp = $parent[0];
					var clientHeight = pp.clientHeight;
					var scrollHeight = pp.scrollHeight;
					if(scrollHeight>clientHeight){
						$parent.height(height);
						$target.data('isBeyond',true);
					}else{
						var $brothersDIV=$target.data('brothersDIV');
						$brothersDIV.each(function(){
							var top  = $(this).position().top;
							$(this).css('top',top+cha);
						});
						$target.data('y',curY);
						$target.data('isBeyond',false);
					}
				}
			}

			function documentMouseUp(e){
				var $target  = $('body');
				var $parent  = $target.data('parent');

				$target.data('move',false);
				$target.data('parent','');
				
				var ownId = $parent.attr('ownId');

				var height = 0;
				$('div.editItem[ownid="'+ownId+'"]').each(function(){
					height+=$(this).height();
				});

				var isBeyond = $target.data('isBeyond');
				if(isBeyond){
					height+=10;
				}
				height = answersheet.toMM(height);
				height+=3;
				var itemType  = $parent.data('itemType');
				$.publish('answersheet.changHeight',ownId,height,itemType);
			}

			answersheet.body.on('mousedown','.move',function(e){

				var $target  = $(e.target);
				var $parent  = $target.data('content');
				var $brothersDIV = $parent.nextAll('div');
				var $body = $('body');

				$body.data('move',true);
				$body.data('y',e.pageY);
				$body.data('parent',$parent);
				$body.data('brothersDIV',$brothersDIV);
				$body.data('isBeyond',false);
				
				$(document).on('mousemove',function(e){
					documentMouseMove(e);
				});
				$(document).on('mouseup',function(e){
					documentMouseUp(e);
					$(document).off('mousemove');
					$(document).off('mouseup');
					return false;
				});

				e.stopPropagation();
				return false;
			});
		}

		$.subscribe('answersheet.changHeight',function(e,ownId,height,itemType){
		
			var itemGroups  = answersheet.data.page.itemGroups;
			$.each(itemGroups,function(idx,itemGroup){
				if(itemType==='answerQuestion'){
					var items  = itemGroup.items;
					var noFind = true;
					$.each(items,function(idx,item){
						if(item.id === ownId){
							item.height=height;
							noFind = false;
							return false;
						}
					});
					return noFind;
				}else{
					if(itemGroup.id === ownId){
						itemGroup.height = height;
						return false;
					}
				}
				
			});
			$.publish('answersheet.reDraw');
		});

		$.subscribe('answersheet.reDraw',function(){
			var pageBodys=answersheet.pageInfo.pageBodys;
			$.each(pageBodys,function(idx,$pageBody){
				$pageBody.empty();
				$pageBody.data('end',2);
			});
			var data  = answersheet.data;
			var itemGroups  = data.page.itemGroups;
			answersheet.plugin[data.page.pageName].reDrawPage(answersheet);

			$.each(itemGroups,function(idx,itemGroup){
				answersheet.plugin[itemGroup.name].create(answersheet,itemGroup);
			});
			answersheet.saveJson();
		});

		$.subscribe('answersheet.new',function(){
			var data  = answersheet.data;
			var itemGroups  = data.page.itemGroups;
			answersheet.plugin[data.page.pageName].createPage(answersheet);
			$.each(itemGroups,function(idx,itemGroup){
				answersheet.plugin[itemGroup.name].create(answersheet,itemGroup);
			});
		});



		return {
			onevent:function(paramsAnswersheet){
				answersheet = paramsAnswersheet;
				init();
			}
		};


	});
})();