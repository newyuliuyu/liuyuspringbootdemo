(function() {
	"use strict";
		
	var models = ['jquery'];
	

	define(models, function($) {

		var answersheet = {

		};

		answersheet.toMM = function(value){
			value = (value/this.px).toFixed2(0);
			return value;
		}

		answersheet.topx = function(value){
			value = (value*this.px).toFixed2(0);
			return value;
		}
		
		answersheet.getCurPageBody = function(){
			var pageInfo = this.pageInfo;
			var idx = pageInfo.curPageBodyIdx;
			return this.pageInfo.pageBodys[idx];
		}

		answersheet.getPageBodyWith = function(){
			var $pageBody = this.getCurPageBody();
			return this.toMM($pageBody.width());
		}

		answersheet.getPageBodyHeight = function(){
			var $pageBody = this.getCurPageBody();
			return this.toMM($pageBody.height());
		}

		answersheet.getBeginPostion = function(){
			var $pageBody = this.getCurPageBody();
			return $pageBody.data('end');
		}

		answersheet.getUnit = function(){
			return this.data.page.unit;
		}

		answersheet.newPage = function(){
			this.plugin[this.data.page.pageName].newPage(this);
		}

		answersheet.nextPage = function(){
			var pageBodySize  = this.pageInfo.pageBodys.length;
			var curIdx  = this.pageInfo.curPageBodyIdx;
			if(curIdx+1 === pageBodySize){
				this.newPage();
			}else{
				this.pageInfo.curPageBodyIdx+=1;
			}
		}
		answersheet.createTextTitle = function(titleName,ownId){
			this.plugin['textTitle'].create(this,titleName,ownId);
		}


		answersheet.setItemGroupTitle = function(title,ownId){
			var itemGroup = this.getItemGroup(ownId);
			itemGroup.title = title;
			this.saveJson();
		}
		answersheet.setItemGroupContent = function(ownId,content){
			var itemGroup = this.getItemGroup(ownId);
			itemGroup.content = content;
			this.saveJson();
		}
		answersheet.getItemGroupContent = function(ownId){
			var itemGroup = this.getItemGroup(ownId);
			return itemGroup.content;
		}
		answersheet.setItemContent = function(itemGroupId,itemId,content){
			var item = this.getItem(itemGroupId,itemId);
			item.content = content;
			this.saveJson();
		}
		answersheet.getItem = function(itemGroupId,itemId){
			var itemGroup = this.getItemGroup(itemGroupId);
			var items  = itemGroup.items;
			var item = undefined;
			$.each(items,function(idx,_item){
				if(_item.id === itemId){
					item = _item;
					return false;
				}

			});
			return item;
		}



		answersheet.getItemGroup = function(ownId){
			var itemGroup = undefined;
			$.each(this.data.page.itemGroups,function(idx,tmp){
				if(tmp.id === ownId){
					itemGroup = tmp;
					return false;
				}
			});
			return itemGroup;
		}

		answersheet.deleteItemGroup = function(ownId,itemType){
			var me = this;
			if(itemType === "answerQuestion"){
				var itemGroups  = this.data.page.itemGroups;
				
				$.each(itemGroups,function(idx,itemGroup){
					if(itemGroup.name === itemType){
						var myIdx = -1;
						var items  = itemGroup.items;
						$.each(items,function(idx2,item){
							if(item.id===ownId){
								myIdx=idx2;
								return false;
							}
						});
						if(myIdx !== -1){
							items.splice(myIdx,1);
							if(items.length ===0){
								itemGroups.splice(idx,1);
							}
							me.saveJson();
							return false;
						}
					}
				});


			}else{
				var itemGroups  = this.data.page.itemGroups;
				var myIdx = -1;
				$.each(itemGroups,function(idx,itemGroup){
					if(itemGroup.id === ownId){
						myIdx = idx;
						return false;
					}
				});
				if(myIdx !== -1){
					itemGroups.splice(myIdx,1);
					this.saveJson();
				}
			}
		}

		answersheet.addItemGroup = function(_itemGroup){
			if(!_itemGroup.id){
				_itemGroup.id = this.uuid();
				this.data.page.itemGroups.push(_itemGroup);
			}else{
				var itemGroup = undefined;
				$.each(this.data.page.itemGroups,function(idx,tmp){
					if(tmp.id === _itemGroup.id){
						itemGroup = tmp;
						return false;
					}
				});
				itemGroup.items = _itemGroup.items.concat(itemGroup.items);
				itemGroup.items.sort(function(i1,i2){
					return i1.no - i2.no;
				});
			}
			this.saveJson();
		}



		answersheet.getMaxNo=function(){
			var size  = this.nos.length; 
			if(this.nos.length > 0){
				return this.nos[size-1]+1;
			}else{
				return 1;
			}
		}




		answersheet.laodJson = function(){
			var dataJson = localStorage['pageJson'];
			var pageData  = undefined;
			try{
				pageData = JSON.parse(dataJson);
			}catch(e){
				pageData = undefined;
			}
			var pageModifyTime = localStorage['pageModifyTime'];
			if(!pageModifyTime){
				pageModifyTime = 0;
			}

			var nowTime  = new Date().getTime();
			var timeInterval = nowTime - pageModifyTime;
			var T  = 1000*60*30;
	
			if(pageData && timeInterval<T){
				this.data.page = pageData;
			}else{
				this.saveJson();
			}
		}

		answersheet.saveJson = function(){
			var pageJson = JSON.stringify(this.data.page);
			var nowTime  = new Date().getTime();
			localStorage['pageModifyTime']=nowTime;
			localStorage['pageJson']=pageJson;
		}



		answersheet.uuid = function(){
			function _randomHexString(len) {
		        var random = Math.randomInt(0, Math.pow(16, len) - 1);
		        return (random.toString(16).pad(len, '0', String.PAD_LEFT));
		    }

		    function generate(type) {
		        switch ((type || 'v4').toUpperCase()) {
		            // Version 4 UUID  (Section 4.4 of RFC 4122)
		            case 'V4':
		                var tl = _randomHexString(8);
		                // time_low
		                var tm = _randomHexString(4);
		                // time_mid
		                var thav = '4' + _randomHexString(3);
		                // time_hi_and_version
		                var cshar = Math.randomInt(0, 0xFF);
		                // clock_seq_hi_and_reserved
		                cshar = ((cshar & ~(1 << 6)) | (1 << 7)).toString(16);
		                var csl = _randomHexString(2);
		                // clock_seq_low
		                var n = _randomHexString(12);
		                // node

		                return (tl + '-' + tm + '-' + thav + '-' + cshar + csl + '-' + n);

		            // Nil UUID  (Section 4.1.7 of RFC 4122)
		            case 'NIL':
		                return ('00000000-0000-0000-0000-000000000000');
		        }
		        return (null);
		    }

		    return generate();
		}




		String.PAD_LEFT = 0;
		String.PAD_RIGHT = 1;
		String.PAD_BOTH = 2;

		String.prototype.pad = function (len, pad, type) {
		    var string = this;
		    var append = new String();

		    len = isNaN(len) ? 0 : len - string.length;
		    pad = typeof (pad) == 'string' ? pad : ' ';

		    if (type == String.PAD_BOTH) {
		        string = string.pad(Math.floor(len / 2) + string.length, pad,
		            String.PAD_LEFT);
		        return (string.pad(Math.ceil(len / 2) + string.length, pad,
		            String.PAD_RIGHT));
		    }

		    while ((len -= pad.length) > 0)
		        append += pad;
		    append += pad.substr(0, len + pad.length);

		    return (type == String.PAD_LEFT ? append.concat(string) :
		        string.concat(append));
		};

		Math.randomInt = function (min, max) {
		    if (!isFinite(min)) min = 0;
		    if (!isFinite(max)) max = 1;
		    return (Math.floor((Math.random() % 1) * (max - min + 1) + min));
		};




		return answersheet;

	});
})();