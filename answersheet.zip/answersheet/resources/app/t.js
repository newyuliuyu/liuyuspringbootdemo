(function() {
	"use strict";
	var models = ['jquery','commons/observer','css!styles/answersheet'];

	define(models, function($) {
		    return {
			    render	: function() {
			    	
			    }
		    }
	    });
})();