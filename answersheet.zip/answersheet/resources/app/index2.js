(function() {
	"use strict";
	var models = ['jquery','answersheet/answersheet','answersheet/addItemBtnEvent','bootstrap','script',
	   'commons/utils','css!styles/bootstrap/bootstrap','css!styles/answersheet','commons/observer'];

	define(models, function($,answersheet) {

		
		$(window).resize(function(){
			myResize();
		});

		function myResize(){
			var height  = $(window).height();
			height=height-50;
			$('#contentBody').height(height);
			$('#toolBar').height(height);
		}

			

		function initUI(){
			var answersheet  = window.answersheet;
			var data = answersheet.data.page;

			$('.layoutName[data-layout="'+data.pageName+'"]').addClass('ok');
			$('.zkzhType[data-barcode="'+data.isBarcode+'"]').attr('checked',true);
			$('#zkzhDiv').radios();
			$('#zkzhNum').attr('disabled',data.isBarcode);
			$('#zkzhNum option[value="'+data.zkzhNumber+'"]').attr('selected',true);
			$.publish('ui.itemGroup.info');
			$('#toolBar').show();
		}

			
			



		$('.layoutName').click(function(){
			$('.layoutName').removeClass('ok');
			$(this).addClass('ok');

			var answersheet  = window.answersheet;
			var layout = $(this).data('layout');
			var pageData  = answersheet.data.page;

			pageData.pageName = layout;
			delete(pageData.width);
			delete(pageData.height);
			delete(answersheet.pageInfo);
			answersheet.body.empty();
			$.publish('answersheet.new');
			answersheet.saveJson();
		});

		$('.zkzhType').click(function(){
			var value  = $(this).val();
			var answersheet = window.answersheet;
			if(value === "T"){
				answersheet.data.page.isBarcode = true;
				$('#zkzhNum').attr('disabled',true);
			}else if(value  === "F"){
				answersheet.data.page.isBarcode = false;
				$('#zkzhNum').attr('disabled',false);
			}
			$.publish('answersheet.reDraw');
			answersheet.saveJson();
		});


		var pageId=ezRequest.QueryString('papgeId');
		if(pageId && pageId.length > 0){
			
		}else{
			var paperName = ezRequest.QueryString('paperName');
			if(!paperName){
				paperName = '';
			}else{
				paperName = decodeURIComponent(paperName);
			}
			answersheet.create(paperName);
		}
		initUI();




			   

	    return {
		    render	: function() {
		    	myResize();
		    }
	    }
	});
})();