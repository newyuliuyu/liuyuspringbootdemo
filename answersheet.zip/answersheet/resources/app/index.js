(function() {
	"use strict";
	var models = ['jquery','commons/observer','css!styles/answersheet'];

	define(models, function($) {

			window.answersheet = {
				page:{
					name:'A4',
					width:210,
					height:297,
					unit:'mm',
					cols:1
				},
				answersheetName:'2017-2018高三单元测试考试\n语文试卷'

			}


			$.subscribe('drawBlock',function(e,$page,answersheet){
				var myPosition={LT:1,RT:2,LB:3,RB:4}
				var baseTop = 11;
				var baseLeft = 6;
				var pageWidth=answersheet.page.width;
				var pageHeight = answersheet.page.height;
				var unit = answersheet.page.unit;

				function oneBlock(position){
					
					var top = 0;
					var left = 0;
					if(position === myPosition.LT){
						top =baseTop;
						left = baseLeft;
					}else if(position === myPosition.RT){
						top =baseTop;
						left = pageWidth-baseLeft-5;
					}else if(position === myPosition.LB){
						top =pageHeight-baseTop-5;
						left = baseLeft;
					}else if(position === myPosition.RB){
						top =pageHeight-baseTop-5;
						left =  pageWidth-baseLeft-5;
					}

					var $block = $('<div>',{css:{
								'background-color':'#000',
								'display':'inline-block',
								'position':'absolute',
								'width':'5mm',
								'height':'5mm',
								'top':top+unit,
								'left':left+unit
						}});
					$page.append($block);
				}
				oneBlock(myPosition.LT);
				oneBlock(myPosition.RT);
				oneBlock(myPosition.LB);
				oneBlock(myPosition.RB);

			});


			$.subscribe('drawPageContent',function(e,$page,answersheet){
				var pageWidth=answersheet.page.width;
				var pageHeight = answersheet.page.height;
				var unit = answersheet.page.unit;

				var $pageContent = $('<div/>',{'class':'pageContent',css:{
					'position':'absolute',
					'border':'1px solid',
					'top':20+unit,
					'left':15+unit,
					'height':(pageHeight-40)+unit,
					'width':(pageWidth-30)+unit
				}});

				$page.append($pageContent);

				$.publish('drawAnswerSheetName',$pageContent,answersheet);
			})


			$.subscribe('drawAnswerSheetName',function(e,$pageContent,answersheet){
				var unit = answersheet.page.unit;
				var width = $pageContent.width();
				width = (width/answersheet.px).toFixed2(0);

				var $titleDiv  = $('<DIV/>',{css:{
					'position':'absolute',
					'width':width+unit,
					'top':0+unit,
					'left':0+unit
				}});

				var $textarea  = $('<textarea/>',{'class':'answersheetTitle',css:{
					'position':'absolute',
					'line-height': 10+unit,
					'font-size': 10+unit,
					'text-align': 'center',
					'resize':'none',
					'width':width+unit,
					'height':20+unit,
					'top':0+unit,
					'left':0+unit
				}}).text(answersheet.answersheetName);
				$titleDiv.append($textarea);
				$pageContent.append($titleDiv);

				$textarea.on('keyup',function(){
					var values = $(this).val().split('\n');
					if(values.length>2){
						$(this).val(values[0]+'\n'+values[1]);
					}
				})

			})
			//



			
			$(window).resize(function(){
				myResize();
			});

			function myResize(){
				var height  = $(window).height();
				height=height-50;
				$('#contentBody').height(height);
				$('#toolBar').height(height);
			}


			function init(){
				var $page  = $('<div>',{css:{
						'background-color':'#fff',
						'display':'inline-block',
						'position':'relative',
						'margin':'50px 0px',
						'width':answersheet.page.width+answersheet.page.unit,
						'height':answersheet.page.height+answersheet.page.unit
				}})

				$('#contentBody').append($page);
				answersheet.px = $page.width()/answersheet.page.width;

				$.publish('drawBlock',$page,answersheet);
				$.publish('drawPageContent',$page,answersheet);
			
				
			}



			init();






			


				   

		    return {
			    render	: function() {
			    	myResize();
			    }
		    }
	    });
})();